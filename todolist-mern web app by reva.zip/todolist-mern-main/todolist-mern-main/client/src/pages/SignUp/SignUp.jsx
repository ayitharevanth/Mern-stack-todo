export default function SignUp() {
  return (
    <div>
      
    </div>
  )
}
