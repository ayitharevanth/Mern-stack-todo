export { default } from "./Splash";
